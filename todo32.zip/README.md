# To-Do List Application (x86 32-bit Assembly)

A console-based To-Do list application for Windows, written entirely in 32-bit x86 Assembly language (NASM).

## Group 3 Members

* "CARTONEROS, BEOMARC ANDREW D."

* "CARVAJAL, CHRISTIAN EZEKIEL L."

* "CASTILLO, CHARLES"

* "GO, MARCO ENRICO S."

* "HANGINON, MARIA FATIMA T."

* "SILVESTRE, DASHIELL B."

## Overview

This project is a fully functional task manager that runs in the Windows console. It uses direct calls to the Windows API (Kernel32) for all console input/output and file operations, with no dependencies on the C standard library.

## Features

* Add, view, update, and delete tasks.

* Toggle the completion status of tasks.

* Save tasks to a file (`tasks.dat`) and load them back.

* Search for tasks using a case-sensitive search.

* Sort tasks (Alphabetically A-Z, Z-A, by complete status).

* Modify the total number of available task slots.

## How to Build

This project is built using `nasm` and the Visual Studio Linker (`link.exe`). The easiest way to build is using the provided batch script.

1. Open the **Developer Command Prompt for VS 2022**. (This ensures `nasm.exe` and `link.exe` are in your path).

2. Navigate to the project directory.

3. Run the build script:

```

build32.bat

```

This will assemble and link the code, creating `todo32.exe` in the same directory.

## Project Explanation (Q&A)

This section covers common questions about the project's design and implementation.

### What is this project?

This is a 32-bit To-Do List application for the Windows console, written entirely in x86 Assembly (NASM). It's a self-contained program that handles task management (add, delete, sort, search) and file persistence, all without relying on any external C libraries.

### How does it print to the screen or read input without C?

We are not using the C standard library (like `printf` or `scanf`). Instead, we make direct calls to the low-level Windows Kernel32 API to interact with the operating system.

* **For Console I/O:** We use `_GetStdHandle@4` to get the "handles" (like IDs) for the console input and output. Then, we use `_WriteFile@20` to print our menus and task lists, and `_ReadFile@20` to get keyboard input from the user.

* **For File Operations:** We use `_CreateFileA@28`, `_WriteFile@20`, `_ReadFile@20`, and `_CloseHandle@4` to save and load the task list to a file named `tasks.dat`.

* **For Animation:** We use `_Sleep@4` to create the brief pause in the loading/saving spinner animation.

### How are the tasks stored in memory?

We use a fixed-size buffer reserved in the `.bss` section:
`tasks resb MAX_TASKS * TASK_SIZE`

* `MAX_TASKS` is a constant set to 30, and `TASK_SIZE` is 64 bytes.

* This reserves a total of 1,920 bytes (30 * 64).

* Each 64-byte slot stores one task. The first 63 bytes are for the task's text (as an ASCII string).

* The very last byte (at offset 63) is a status flag: `0` for incomplete, `1` for complete.

* We use a variable called `task_count` to keep track of how many tasks are *actually* in use, and `max_tasks_limit` for the user's chosen slot limit.

### What algorithms did you implement?

We implemented several key algorithms from scratch:

* **Sorting:** We use a **Bubble Sort** (e.g., `bubble_sort_alpha_asc`, `bubble_sort_incomplete_first`). This algorithm works by repeatedly stepping through the list, comparing adjacent tasks, and swapping them if they are in the wrong order. It continues doing this until no more swaps are needed.

* **String Comparison:** The `compare_strings` function is used by the bubble sort. It compares two task strings byte-by-byte to decide which one comes first alphabetically.

* **Substring Search:** The `string_contains` function implements the search feature. It iterates through a task's string, and for every character that matches the *first* character of the search term, it checks if the subsequent characters also match.

* **Integer to String:** The `num_to_string` function converts integer values (like the `task_count`) into an ASCII string. This is necessary because `_WriteFile@20` can only print strings, not raw numbers.

### How does the Save/Load feature work?

The save/load functions provide data persistence.

* **Save:** We first write the current `max_tasks_limit` (4 bytes) and `task_count` (4 bytes) to the `tasks.dat` file. Then, we write the *entire* active portion of the task buffer (`task_count * TASK_SIZE` bytes) directly to the file.

* **Load:** We do the reverse. We open `tasks.dat`, read the first 4 bytes into the `max_tasks_limit` variable, the next 4 bytes into `task_count`, and then read the rest of the file's data directly back into our `tasks` buffer in memory.
```